﻿// ================================================================
// FILE: remote-control.js (ĐÃ SỬA LỖI)
// ================================================================

var socketUrl = "ws://" + window.location.host + "/ws";
var socket = new WebSocket(socketUrl);

// 1. KHI KẾT NỐI THÀNH CÔNG
socket.onopen = function (event) {
    console.log("Connected!");
    var statusDiv = document.getElementById("connectionStatus");
    statusDiv.innerText = "Đã kết nối Admin (Ready)";
    statusDiv.className = "alert alert-success";

    // Ẩn màn hình tối nếu có
    document.getElementById("deadOverlay").style.display = "none";
};

// 2. KHI MẤT KẾT NỐI (HIỆN DEAD BODY REPORTED)
// KHI MẤT KẾT NỐI (Sửa lại đoạn này)
socket.onclose = function (event) {
    var statusDiv = document.getElementById("connectionStatus");

    // Chỉ báo dòng chữ thôi, đừng hiện màn hình đen vội
    statusDiv.innerText = "MẤT KẾT NỐI (SERVER OFF)";
    statusDiv.className = "alert alert-danger";

    // --- QUAN TRỌNG: KHÓA 2 DÒNG NÀY LẠI ĐỂ KHÔNG BỊ ĐEN MÀN HÌNH ---
    // statusDiv.className = "dead-body-alert"; 
    // document.getElementById("deadOverlay").style.display = "block"; 
};

// 3. NHẬN DỮ LIỆU TỪ SERVER
socket.onmessage = function (event) {
    var data;
    try { data = JSON.parse(event.data); } catch (e) { return; }

    var imgTag = document.getElementById("imgResult");
    var textTag = document.getElementById("textResult");

    if (data.type === "HINH_ANH") {
        textTag.style.display = "none";
        imgTag.style.display = "block";
        imgTag.src = "data:image/jpeg;base64," + data.payload;
    }
    else { // VĂN BẢN
        imgTag.style.display = "none";
        textTag.style.display = "block";
        textTag.innerText = data.payload;
    }
};

// 4. HÀM GỬI LỆNH
function guiLenh(cmd, param = "") {
    if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ command: cmd, param: param }));
        // Hiện thông báo chờ trên màn hình tablet
        document.getElementById("textResult").innerText = ">> Đang gửi lệnh: " + cmd + "...\n>> Chờ phản hồi...";
        document.getElementById("textResult").style.display = "block";
        document.getElementById("imgResult").style.display = "none";
    } else {
        alert("Đã mất kết nối! Không thể gửi lệnh.");
    }
}

// 5. GÁN SỰ KIỆN CHO CÁC NÚT (KHỚP VỚI FILE INDEX)
document.addEventListener("DOMContentLoaded", function () {

    // Nút Chụp màn hình (Mới)
    var btnShot = document.getElementById("btnScreenshot");
    if (btnShot) btnShot.onclick = function () { guiLenh("SCREENSHOT"); };

    // Nút Webcam
    var btnCam = document.getElementById("btnWebcam");
    if (btnCam) btnCam.onclick = function () { guiLenh("WEBCAM"); };

    // Nút Keylog
    var btnKey = document.getElementById("btnKeylog");
    if (btnKey) btnKey.onclick = function () { guiLenh("KEYLOG"); };

    // Nút Apps
    var btnApps = document.getElementById("btnListApps");
    if (btnApps) btnApps.onclick = function () { guiLenh("APPLIST"); };

    // Nút Processes
    var btnProcs = document.getElementById("btnListProcesses");
    if (btnProcs) btnProcs.onclick = function () { guiLenh("PROCLIST"); };

    // Nút Chạy lệnh
    var btnRun = document.getElementById("btnRunCommand");
    if (btnRun) btnRun.onclick = function () {
        var cmd = prompt("Nhập lệnh hoặc tên App:", "");
        if (cmd) guiLenh("RUN", cmd);
    };

    // Nút Restart
    var btnRes = document.getElementById("btnRestart");
    if (btnRes) btnRes.onclick = function () {
        if (confirm("Bạn có chắc muốn Khởi động lại máy không?")) guiLenh("RESTART");
    };

    // Nút Shutdown
    var btnShut = document.getElementById("btnShutdown");
    if (btnShut) btnShut.onclick = function () {
        if (confirm("CẢNH BÁO: Tắt máy ngay lập tức?")) guiLenh("SHUTDOWN");
    };
});
﻿// ================================================================
// CẤU HÌNH KẾT NỐI
// ================================================================
const WS_URL = "ws://localhost:5000";
let socket;
let isConnected = false;
let isSystemCommandSent = false; // Cờ đánh dấu để đổi icon khi Shutdown/Restart

// CÁC PHẦN TỬ GIAO DIỆN
const imgScreen = document.getElementById('imgResult');
const textLog = document.getElementById('textResult');
const listScreen = document.getElementById('listResult');
const keylogScreen = document.getElementById('keylogResult'); 
const statusBox = document.getElementById('connectionStatus');
const loadingScreen = document.getElementById('loadingSpinner');

// BIẾN TẠM
let keylogBuffer = "";
let lastBlob = null;
let lastFileName = "";
let lastObjectUrl = null;

// ÂM THANH
const soundClick = new Audio('https://www.myinstants.com/media/sounds/among-us-chat-sound.mp3');
const soundError = new Audio('https://www.myinstants.com/media/sounds/among-us-error.mp3');

function playSound(type) {
    if (type === 'click') {
        soundClick.currentTime = 0;
        soundClick.play().catch(e => { });
    } else if (type === 'error') {
        soundError.play().catch(e => { });
    }
}

// ================================================================
// 1. QUẢN LÝ KẾT NỐI SOCKET
// ================================================================
function connectToServer() {
    if (isConnected) {
        showToast("Máy đã kết nối rồi!");
        return;
    }

    playSound('click');

    // Trạng thái Đang kết nối (Màu cam)
    statusBox.classList.remove("alert-danger", "alert-success", "alert-warning");
    statusBox.classList.add("alert-connecting");
    statusBox.innerHTML = `<i class="fas fa-satellite-dish fa-spin"></i> ĐANG KẾT NỐI...`;

    setTimeout(() => {
        try {
            socket = new WebSocket(WS_URL);
            socket.binaryType = "arraybuffer";

            socket.onopen = function (e) {
                isConnected = true;
                isSystemCommandSent = false; // Reset cờ khi mới kết nối
                statusBox.classList.remove("alert-connecting");
                updateStatus('<i class="fas fa-wifi"></i> ĐÃ KẾT NỐI', "alert-warning", "alert-success");
                showToast("Kết nối thành công!");
                console.log(">> Đã kết nối tới Server!");
            };

            socket.onmessage = (event) => {
                processData(event.data);
            };

            socket.onclose = function (event) {
                isConnected = false;
                statusBox.classList.remove("alert-connecting");

                // Trả các nút Restart/Shutdown về bình thường nếu bị kẹt
                resetSystemButtons();

                // Phân biệt icon theo ý bạn
                if (isSystemCommandSent) {
                    updateStatus('<i class="fas fa-power-off"></i> HỆ THỐNG ĐÃ TẮT', "alert-success", "alert-danger");
                } else {
                    updateStatus('<i class="fas fa-exclamation-triangle"></i> MẤT KẾT NỐI', "alert-success", "alert-danger");
                }
                isSystemCommandSent = false;
            };

            socket.onerror = function (error) {
                isConnected = false;
                statusBox.classList.remove("alert-connecting");
                updateStatus('<i class="fas fa-bomb"></i> LỖI KẾT NỐI', "alert-success", "alert-danger");
            };

        } catch (err) {
            statusBox.classList.remove("alert-connecting");
            updateStatus('<i class="fas fa-bug"></i> LỖI URL', "alert-success", "alert-danger");
        }
    }, 500);
}

function updateStatus(msg, removeClass, addClass) {
    statusBox.innerHTML = msg;
    statusBox.classList.remove(removeClass);
    statusBox.classList.add(addClass);
}

// ================================================================
// 2. XỬ LÝ DỮ LIỆU (Cập nhật Mã 4 & Ô Keylog riêng)
// ================================================================
function processData(arrayBuffer) {
    const dataView = new DataView(arrayBuffer);
    const dataType = dataView.getUint8(0);

    // Tắt loading ngay khi có dữ liệu về
    if (loadingScreen) loadingScreen.style.display = "none";

    if (dataType === 4) {
        const status = dataView.getUint8(1); // Byte 1: 0 hoặc 1
        const detail = new TextDecoder("utf-8").decode(arrayBuffer.slice(2)); // Còn lại là thông báo

        resetSystemButtons(); // Ngừng nhấp nháy các nút hệ thống khi nhận phản hồi

        if (status === 1) {
            showToast("✔️ THÀNH CÔNG: " + detail);
            playSound('click');
        } else {
            showToast("❌ THẤT BẠI: " + detail);
            playSound('error');
            isSystemCommandSent = false;
        }
        return;
    }

    // Ẩn các màn hình trước khi hiện cái mới
    hideAllScreens();
    const rawData = arrayBuffer.slice(1);

    // CASE 0: ẢNH
    if (dataType === 0) {
        imgScreen.style.display = "block";
        const blob = new Blob([rawData], { type: "image/jpeg" });
        lastBlob = blob;
        lastFileName = "screenshot.jpg";
        if (lastObjectUrl) URL.revokeObjectURL(lastObjectUrl);
        lastObjectUrl = URL.createObjectURL(blob);
        imgScreen.src = lastObjectUrl;
    }
    // CASE 1: KEYLOG 
    else if (dataType === 1) {
        keylogScreen.style.display = "block";
        const text = new TextDecoder("utf-8").decode(rawData);
        keylogScreen.innerText += text;
        keylogScreen.scrollTop = keylogScreen.scrollHeight;
        keylogBuffer += text;
    }
    // CASE 2: VIDEO/WEBCAM
    else if (dataType === 2) {
        let video = document.getElementById("videoResult");
        if (!video) {
            video = document.createElement("video");
            video.id = "videoResult";
            video.controls = true;
            video.style.width = "100%";
            imgScreen.closest(".tablet-screen").appendChild(video);
        }
        const blob = new Blob([rawData], { type: "video/mp4" });
        if (lastObjectUrl) URL.revokeObjectURL(lastObjectUrl);
        lastObjectUrl = URL.createObjectURL(blob);
        video.src = lastObjectUrl;
        video.style.display = "block";
        video.play();
        lastBlob = blob;
        lastFileName = "webcam.mp4";
    }
    // CASE 3: LIST JSON (Apps/Processes)
    else if (dataType === 3) {
        listScreen.style.display = "block";
        const text = new TextDecoder("utf-8").decode(rawData);
        try {
            const list = JSON.parse(text);
            renderAppList(list);
        } catch (e) { console.error("Lỗi parse JSON:", e); }
    }
}

// ================================================================
// 3. GỬI LỆNH & GIAO DIỆN
// ================================================================
function sendCommand(cmdInput) {
    let payload = (typeof cmdInput === "object") ? cmdInput : { command: cmdInput };
    if (TEST_MODE) {
        console.log("[TEST] Thực thi lệnh:", payload.command);
        if (loadingScreen) loadingScreen.style.display = "none";

        // Gọi hàm giả lập
        simulateTestResponse(payload);
        return; // Dừng lại không gửi WebSocket
    }
    let jsonString = JSON.stringify(payload); 

    // Hiệu ứng cho nút hệ thống
    if (payload.command === 'RESTART' || payload.command === 'SHUTDOWN') {
        isSystemCommandSent = true;
        const btnId = payload.command === 'RESTART' ? 'btnRestart' : 'btnShutdown';
        const btn = document.getElementById(btnId);
        if (btn) {
            btn.classList.add('loading');
            btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${payload.command}ING...`;
        }
    } else {
        showLoading(); // Các lệnh khác thì hiện "Processing..."
    }

    if (socket && isConnected) {
        socket.send(jsonString);
    }
}

// Hàm gỡ bỏ trạng thái loading của nút (Fix lỗi kẹt chữ)
function resetSystemButtons() {
    const btnR = document.getElementById('btnRestart');
    const btnS = document.getElementById('btnShutdown');
    if (btnR) {
        btnR.classList.remove('loading');
        btnR.innerHTML = `<i class="fas fa-sync-alt"></i> RESTART`;
    }
    if (btnS) {
        btnS.classList.remove('loading');
        btnS.innerHTML = `<i class="fas fa-power-off"></i> SHUTDOWN`;
    }
}

function renderAppList(list) {
    listScreen.innerHTML = "";
    list.forEach(item => {
        let isRunning = (item.pid && item.pid > 0);
        let actionBtnHtml = isRunning ?
            `<div class="btn-among-us btn-red" onclick="handleStopApp(this, ${item.pid})">⛔ STOP</div>` :
            `<div class="btn-among-us btn-green" onclick="sendCommand({command:'START_APP', name:'${item.name}'}); showToast('Đang mở ${item.name}...')">▶ START</div>`;

        listScreen.innerHTML += `
            <div class="list-item ${isRunning ? 'running' : ''}">
                <div class="name">🧑‍🚀 ${item.name}</div>
                <div class="pid">PID: ${isRunning ? item.pid : '---'}</div>
                <div class="list-actions">${actionBtnHtml}</div>
            </div>`;
    });
}

function handleStopApp(btn, pid) {
    // Thêm hiệu ứng mờ dòng khi bấm Stop
    const row = btn.closest('.list-item');
    if (row) {
        row.style.opacity = "0.5";
        btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i>`;
    }
    sendCommand({ command: "STOP_APP", pid: pid });
}

function hideAllScreens() {
    const screens = [imgScreen, textLog, listScreen, keylogScreen, loadingScreen];
    screens.forEach(s => { if (s) s.style.display = "none"; });
    const video = document.getElementById("videoResult");
    if (video) { video.pause(); video.style.display = "none"; }
}

function showLoading() {
    hideAllScreens();
    if (loadingScreen) {
        loadingScreen.style.display = "flex";
        loadingScreen.style.flexDirection = "column";
        loadingScreen.style.justifyContent = "center";
        loadingScreen.style.alignItems = "center";
        loadingScreen.style.height = "100%";
    }
}

// --- TIỆN ÍCH KHÁC ---
function highlightButton(activeBtnId) {
    playSound('click');
    const buttons = ["btnScreenshot", "btnWebcam", "btnKeylog", "btnListApps", "btnListProcesses"];
    buttons.forEach(id => {
        const btn = document.getElementById(id);
        if (btn) btn.classList.remove("btn-active");
    });
    const targetBtn = document.getElementById(activeBtnId);
    if (targetBtn) targetBtn.classList.add("btn-active");
}

function showToast(message, isError = false) {
    const box = document.getElementById("toast-box");
    if (!box) return;

    const toast = document.createElement("div");
    toast.classList.add("toast-msg");

    // Nếu là lỗi thì đổi màu viền sang Đỏ (Red)
    if (isError) {
        toast.style.borderColor = "#ff0000";
        toast.style.boxShadow = "0 4px 15px rgba(255, 0, 0, 0.3)";
    }

    // Icon tên lửa hoặc cảnh báo
    const icon = isError ? "⚠️" : "🚀";

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;

    box.appendChild(toast);

    // Tự động xóa sau 3 giây
    setTimeout(() => {
        toast.style.animation = "fadeOut 0.5s forwards";
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}
function downloadKeylog() {
    if (!keylogBuffer || keylogBuffer.trim() === "") {
        showToast("Chưa có dữ liệu log để tải!", true);
        return;
    }
    const blob = new Blob([keylogBuffer], { type: 'text/plain' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Keylog_${new Date().getTime()}.txt`;
    link.click();
    showToast("Đã tải xuống file log!");
}

function saveFile() {
    if (!lastBlob) { showToast("Chưa có dữ liệu!"); return; }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(lastBlob);
    a.download = lastFileName;
    a.click();
}

function startAppByName() {
    const appName = document.getElementById("appNameInput").value.trim();
    if (!appName) { showToast("Vui lòng nhập tên app!"); return; }
    sendCommand({ command: "START_APP", name: appName });
}

// HIỆU ỨNG SÓNG (RIPPLE) KHI CLICK NÚT
document.addEventListener('click', function (e) {
    const target = e.target.closest('.btn-among-us');
    if (target) {
        const circle = document.createElement('span');
        const diameter = Math.max(target.clientWidth, target.clientHeight);
        circle.style.width = circle.style.height = `${diameter}px`;
        const rect = target.getBoundingClientRect();
        circle.style.left = `${e.clientX - rect.left - diameter / 2}px`;
        circle.style.top = `${e.clientY - rect.top - diameter / 2}px`;
        circle.classList.add('ripple');
        target.appendChild(circle);
        setTimeout(() => circle.remove(), 600);
    }
});









let TEST_MODE = true;
function toggleTestMode() {
    TEST_MODE = !TEST_MODE;

    if (TEST_MODE) {
        showToast("TEST MODE: ON (Không cần WebSocket)");
        statusBox.innerHTML = `<i class="fas fa-vial"></i> TEST MODE`;
        statusBox.classList.remove("alert-danger", "alert-success", "alert-warning");
        statusBox.classList.add("alert-warning");
    } else {
        showToast("TEST MODE: OFF");
        statusBox.innerHTML = `<i class="fas fa-plug"></i> KẾT NỐI`;
        statusBox.classList.remove("alert-warning");
    }
}




// Thêm từ khóa async để xử lý fetch file ảnh/video thành Blob
async function simulateTestResponse(cmd) {
    hideAllScreens();

    // Lấy tên lệnh từ object payload hoặc string trực tiếp
    const commandName = (typeof cmd === "object") ? cmd.command : cmd;

    switch (commandName) {
        case "GET_SCREENSHOT":
            // 1. Hiển thị lên giao diện
            imgScreen.src = "images/test.jpg";
            imgScreen.style.display = "block";

            // 2. Cập nhật dữ liệu để nút SAVE hoạt động
            lastFileName = "screenshot_test.jpg";
            try {
                const response = await fetch("images/test.jpg");
                lastBlob = await response.blob();
                showToast("MOCK: Đã lấy ảnh (Có thể lưu)");
            } catch (e) {
                console.error("Lỗi fetch ảnh test:", e);
            }
            break;

        case "START_WEBCAM":
            // 1. Tìm hoặc tạo video element
            let video = document.getElementById("videoResult");
            if (!video) {
                video = document.createElement("video");
                video.id = "videoResult";
                video.controls = true;
                video.style.width = "100%";
                imgScreen.closest(".tablet-screen").appendChild(video);
            }
            video.src = "images/test.mp4";
            video.style.display = "block";
            video.play();

            // 2. Cập nhật dữ liệu để nút SAVE hoạt động
            lastFileName = "webcam_test.mp4";
            try {
                const response = await fetch("images/test.mp4");
                lastBlob = await response.blob();
                showToast("MOCK: Đang stream (Có thể lưu)");
            } catch (e) {
                console.error("Lỗi fetch video test:", e);
            }
            break;

        case "GET_KEYLOG":
            keylogScreen.style.display = "block";
            const time = new Date().toLocaleTimeString();
            const mockContent = `\n[${time}] Phím gõ: "Admin_Test_123"`;

            // Cập nhật cả màn hình và bộ nhớ đệm (buffer) để nút DOWNLOAD hoạt động
            keylogScreen.innerText += mockContent;
            keylogBuffer += mockContent;

            keylogScreen.scrollTop = keylogScreen.scrollHeight;
            showToast("MOCK: Đã nhận dữ liệu phím");
            break;

        case "GET_APPS":
        case "GET_PROCESSES":
            // HIỆN khung danh sách (Quan trọng: Code cũ thường thiếu dòng này)
            listScreen.style.display = "block";
            renderAppList([
                { name: "Chrome.exe", pid: 1024 },
                { name: "AmongUs_Game.exe", pid: 9999 },
                { name: "VS_Code.exe", pid: 0 }
            ]);
            showToast(`MOCK: Danh sách ${commandName === "GET_APPS" ? 'ứng dụng' : 'tiến trình'}`);
            break;

        case "STOP_APP":
            showToast(`MOCK: Đang dừng PID ${cmd.pid}...`);
            setTimeout(() => {
                showToast("✔️ Thành công: Tiến trình đã đóng", false);
                simulateTestResponse("GET_APPS"); // Refresh lại danh sách
            }, 1000);
            break;

        case "SHUTDOWN":
        case "RESTART":
            showToast(`MOCK: Đang gửi lệnh ${commandName}...`);
            setTimeout(() => {
                resetSystemButtons(); // Tắt hiệu ứng loading trên nút
                showToast(`✔️ Hệ thống đang ${commandName.toLowerCase()}...`);
            }, 2000);
            break;

        default:
            showToast(`Lệnh [${commandName}] chưa có Mock!`, true);
    }
}